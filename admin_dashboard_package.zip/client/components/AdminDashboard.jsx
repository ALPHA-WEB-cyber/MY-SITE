import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/admin/stats', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setStats(res.data);
      } catch (err) {
        console.error('Failed to fetch stats:', err);
      }
    };

    fetchStats();
  }, [token]);

  if (!stats) return <p>Loading dashboard...</p>;

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">📊 Admin Dashboard</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-center">
        <StatCard label="Total Users" value={stats.totalUsers} color="bg-blue-500" />
        <StatCard label="Banned Users" value={stats.bannedUsers} color="bg-red-500" />
        <StatCard label="New This Week" value={stats.newThisWeek} color="bg-green-500" />
        <StatCard label="Admins" value={stats.adminCount} color="bg-purple-500" />
        <StatCard label="Messages" value={stats.totalMessages} color="bg-yellow-500" />
      </div>
    </div>
  );
}

function StatCard({ label, value, color }) {
  return (
    <div className={`rounded-lg p-4 text-white ${color}`}>
      <div className="text-xl font-semibold">{value}</div>
      <div className="text-sm">{label}</div>
    </div>
  );
}
