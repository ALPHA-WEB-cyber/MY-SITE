const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Message = require('../models/Message'); // Assuming you have this
const { authenticateToken, requireAdmin } = require('../middleware/auth');

router.get('/stats', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const [totalUsers, bannedUsers, newThisWeek, adminCount, totalMessages] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ banned: true }),
      User.countDocuments({ createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } }),
      User.countDocuments({ role: 'admin' }),
      Message.countDocuments()
    ]);

    res.json({
      totalUsers,
      bannedUsers,
      newThisWeek,
      adminCount,
      totalMessages
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to fetch admin stats' });
  }
});

module.exports = router;
